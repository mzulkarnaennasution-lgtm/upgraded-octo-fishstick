<?php
// Endpoint for IoT device to POST room status
// Expects POST: room_id, status (free|occupied), optional note
require_once __DIR__ . "/../db.php";

header('Content-Type: application/json');

$room_id = $_POST['room_id'] ?? null;
$status = $_POST['status'] ?? null;
$note = $_POST['note'] ?? null;

if (!$room_id || !$status) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'msg'=>'room_id and status required']);
    exit;
}

$status = $status === 'occupied' ? 'occupied' : 'free';

try {
    // insert history
    $stmt = $pdo->prepare("INSERT INTO room_status (room_id, status, note) VALUES (?, ?, ?)");
    $stmt->execute([$room_id, $status, $note]);

    // update current status in rooms
    $stmt = $pdo->prepare("UPDATE rooms SET current_status = ? WHERE id = ?");
    $stmt->execute([$status, $room_id]);

    echo json_encode(['ok'=>true]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]);
}
?>
