<?php
require_once __DIR__ . '/../db.php';

$room_id = $_GET['room_id'] ?? null;
$status  = $_GET['status'] ?? null;

if (!$room_id || !$status) {
    echo "ERROR: missing parameters";
    exit;
}

$update = $pdo->prepare("UPDATE rooms SET current_status=? WHERE id=?");
$update->execute([$status, $room_id]);

echo "OK";
