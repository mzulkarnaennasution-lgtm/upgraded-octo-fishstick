<?php
require_once __DIR__ . '/../db.php';
session_start();

// Ambil history ruangan + nama ruangan
$sql = "
    SELECT 
        h.timestamp,
        h.status,
        r.name AS room_name,
        h.room_id
    FROM room_history h
    JOIN rooms r ON h.room_id = r.id
    ORDER BY h.room_id, h.timestamp ASC
";

$rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

$results = [];
$last_in = [];

// Proses perhitungan durasi
foreach ($rows as $row) {

    $room_id = $row["room_id"];
    $status  = $row["status"];
    $time    = $row["timestamp"];

    if ($status === "occupied") {
        $last_in[$room_id] = $time;
    }

    elseif ($status === "free" && isset($last_in[$room_id])) {

        $masuk  = strtotime($last_in[$room_id]);
        $keluar = strtotime($time);

        if ($keluar > $masuk) {
            $durasi = ($keluar - $masuk) / 3600;

            if ($durasi >= 2) {
                $results[] = [
                    "room"   => $row["room_name"],
                    "masuk"  => $last_in[$room_id],
                    "keluar" => $time,
                    "durasi" => round($durasi, 2)
                ];
            }
        }

        unset($last_in[$room_id]);
    }
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>History Pemakaian Ruangan</title>

<style>
/* Global */
body {
    margin: 0;
    font-family: Arial;
    background: #f5f6fa;
}

/* Header */
.header {
    height: 60px;
    background: #34495e;
    color: #fff;
    display: flex;
    justify-content: space-between;
    padding: 15px 20px;
    align-items: center;
}
.header .brand {
    font-size: 20px;
    font-weight: bold;
}

/* Layout */
.container {
    display: flex;
}

.sidebar {
    width: 220px;
    min-height: 100vh;
    background: #2c3e50;
    padding-top: 20px;
}
.sidebar a {
    display: block;
    padding: 12px 20px;
    color: #ecf0f1;
    text-decoration: none;
}
.sidebar a:hover,
.sidebar a.active {
    background: #1abc9c;
}

.content {
    flex: 1;
    padding: 20px;
}

/* Tabel */
table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    margin-top: 15px;
    border-radius: 10px;
    overflow: hidden;
}
th {
    background: #263238;
    color: #fff;
    padding: 12px;
}
td {
    padding: 12px;
    border-bottom: 1px solid #ddd;
}
tr:hover {
    background: #f0f0f0;
}
.empty {
    text-align: center;
    padding: 20px;
    font-style: italic;
    color: #777;
}
</style>

</head>

<body>

<!-- HEADER -->
<div class="header">
    <div class="brand">History Pemakaian Ruangan</div>

    <div class="user">
        Hai, <?= $_SESSION['user'] ?? "Pengunjung" ?> |
        <a href="../logout.php" style="color:#fff;text-decoration:none;">Logout</a>
    </div>
</div>

<!-- MAIN WRAPPER -->
<div class="container">

    <!-- SIDEBAR -->
    <div class="sidebar">
        <a href="dashboard_admin.php">📊 Dashboard</a>
        <a href="rooms.php">🏢 Ruangan</a>
        <a href="history.php" class="active">📜 History</a>
        <a href="users.php">👥 User</a>
    </div>

    <!-- CONTENT -->
    <div class="content">

        <h2>Riwayat Ruangan (≥ 2 Jam)</h2>

        <table>
            <tr>
                <th>Ruangan</th>
                <th>Waktu Masuk</th>
                <th>Waktu Keluar</th>
                <th>Durasi (Jam)</th>
            </tr>

            <?php if (!empty($results)): ?>
                <?php foreach ($results as $h): ?>
                <tr>
                    <td><?= htmlspecialchars($h['room']) ?></td>
                    <td><?= htmlspecialchars($h['masuk']) ?></td>
                    <td><?= htmlspecialchars($h['keluar']) ?></td>
                    <td><?= htmlspecialchars($h['durasi']) ?></td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="empty">Tidak ada ruangan yang digunakan lebih dari 2 jam.</td>
                </tr>
            <?php endif; ?>

        </table>

    </div>

</div>

</body>
</html>
