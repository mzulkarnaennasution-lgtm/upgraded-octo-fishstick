<?php
require_once __DIR__ . '/../db.php';

// Ambil semua ruangan
$rooms = $pdo->query("SELECT * FROM rooms ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

// Hapus ruangan
if (isset($_GET["delete"])) {
    $id = intval($_GET["delete"]);
    $del = $pdo->prepare("DELETE FROM rooms WHERE id=?");
    $del->execute([$id]);

    echo "<script>alert('Ruangan dihapus');window.location='rooms.php';</script>";
    exit;
}

// Path uploads
$uploadUrl = "../uploads/";
$uploadDir = dirname(__DIR__) . "/uploads/";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Ruangan</title>

    <!-- CSS Dashboard -->
    <link rel="stylesheet" href="../assets/css/admin-dashboard.css">

    <style>
        .room-thumb {
            width: 85px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0 0 5px rgba(0,0,0,0.2);
        }
        .status-free {
            color: #2ecc71;
            font-weight: bold;
        }
        .status-occupied {
            color: #e74c3c;
            font-weight: bold;
        }
        .table-box {
            background: white;
            padding: 20px;
            border-radius: 14px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.07);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table th {
            background: #2A3F54;
            color: white;
            padding: 12px;
        }
        table td {
            padding: 12px;
            background: #fafafa;
        }
        table tr:nth-child(even) td {
            background: #f1f1f1;
        }
        table tr:hover td {
            background: #e8e8e8;
        }
    </style>
</head>

<body>

<!-- HEADER -->
<div class="top-nav">
    <div class="left">
        <span class="brand">Kelola Ruangan</span>
    </div>
    <div class="right">
        <img src="../uploads/default.png" class="top-avatar">
        <span>Admin</span>
    </div>
</div>

<div class="wrapper">

    <!-- SIDEBAR -->
    <div class="sidebar">
        <div class="profile-box">
            <img src="../uploads/default.png" class="profile-photo">
            <div class="profile-name">Admin</div>
        </div>

        <a href="dashboard_admin.php">📊 Dashboard</a>
        <a href="rooms.php" class="active">🏢 Ruangan</a>
        <a href="history.php">📜 History</a>
        <a href="users.php">👥 User</a>
    </div>

    <!-- CONTENT -->
    <div class="content">

        <h2 class="section-title">Daftar Ruangan</h2>

        <a href="add_room.php" class="btn">➕ Tambah Ruangan</a>
        <br><br>

        <div class="table-box">

            <table>
                <tr>
                    <th>ID</th>
                    <th>Gambar</th>
                    <th>Nama Ruangan</th>
                    <th>Lokasi</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>

                <?php foreach ($rooms as $r): ?>
                <?php
                    // Ambil gambar
                    $imgFile = $r['image'] ?: "default_room.png";
                    $fullPath = $uploadDir . $imgFile;

                    // Jika file tidak ada → pakai default
                    $foto = file_exists($fullPath) ? $uploadUrl . $imgFile : $uploadUrl . "default_room.png";
                ?>
                <tr>
                    <td><?= $r["id"] ?></td>

                    <td>
                        <img src="<?= $foto ?>" class="room-thumb" alt="room">
                    </td>

                    <td><?= htmlspecialchars($r["name"]) ?></td>
                    <td><?= htmlspecialchars($r["location"]) ?></td>

                    <td>
                        <?php if ($r["current_status"] === "occupied"): ?>
                            <span class="status-occupied">BERISI</span>
                        <?php else: ?>
                            <span class="status-free">KOSONG</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <a href="edit_room.php?id=<?= $r['id'] ?>">✏ Edit</a> |
                        <a href="rooms.php?delete=<?= $r['id'] ?>" onclick="return confirm('Hapus ruangan ini?')">🗑 Hapus</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>

        </div>

    </div>

</div>

</body>
</html>
