<?php
require_once __DIR__ . '/../db.php';
session_start();


if (!isset($_GET["id"])) {
    die("ID ruangan tidak diberikan!");
}

$id = $_GET["id"];

$q = $pdo->prepare("SELECT * FROM rooms WHERE id=?");
$q->execute([$id]);
$room = $q->fetch(PDO::FETCH_ASSOC);

if (!$room) {
    die("Ruangan tidak ditemukan!");
}


if (isset($_POST["submit"])) {

    $name   = $_POST["name"];
    $status = $_POST["status"];

      $image_name = $room['image'];

    if (!empty($_FILES['image']['name'])) {

        $file = $_FILES['image'];
        $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        $valid = ['jpg','jpeg','png'];

        if (in_array($ext, $valid)) {

            $newName = "room_" . time() . "." . $ext;
            $path = "../uploads/" . $newName;

            move_uploaded_file($file['tmp_name'], $path);

            if (!empty($room['image']) && file_exists("../uploads/".$room['image'])) {
                unlink("../uploads/".$room['image']);
            }

            $image_name = $newName;
        }
    }

    $update = $pdo->prepare("UPDATE rooms SET name=?, current_status=?, image=? WHERE id=?");
    $update->execute([$name, $status, $image_name, $id]);

    echo "<script>alert('Ruangan berhasil diperbarui!');window.location='rooms.php';</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Ruangan</title>
    <link rel="stylesheet" href="../assets/css/style.css">

    <style>
        .preview-img {
            width: 160px;
            height: 120px;
            object-fit: cover;
            border-radius: 8px;
            margin-top: 10px;
            box-shadow: 0 0 6px rgba(0,0,0,0.2);
        }
    </style>
</head>

<body>

<div class="header">
    <div class="brand">Edit Ruangan</div>

    <div class="user">
        Hai, <?= $_SESSION['admin'] ?? 'Pengunjung' ?>
    </div>
</div>

<div class="container grid">

    <div class="sidebar">
        <a href="dashboard.php">Dashboard</a>
        <a href="rooms.php" class="active">Ruangan</a>
        <a href="history.php">History</a>
        <a href="users.php">User</a>
    </div>

    <div class="content">
        <div class="card">
            <h2>Edit Ruangan</h2>

            <form method="POST" enctype="multipart/form-data">

                <label>Nama Ruangan</label><br>
                <input type="text" name="name"
                       value="<?= htmlspecialchars($room['name']) ?>" required><br><br>

                <label>Status</label><br>
                <select name="status">
                    <option value="free"     <?= $room['current_status']=="free" ? "selected":"" ?>>Kosong</option>
                    <option value="occupied" <?= $room['current_status']=="occupied" ? "selected":"" ?>>Terisi</option>
                </select>
                <br><br>

                <label>Gambar Ruangan (Opsional)</label><br>
                <input type="file" name="image" accept="image/*"><br>

                <?php 
                $path = "../uploads/" . $room['image'];
                if (!empty($room['image']) && file_exists($path)): ?>
                    <img src="<?= $path ?>" class="preview-img">
                <?php else: ?>
                    <p style="color:#777;">(Tidak ada gambar)</p>
                <?php endif; ?>

                <br><br>

                <button type="submit" name="submit" class="btn">Update</button>

            </form>
        </div>
    </div>

</div>

</body>
</html>
