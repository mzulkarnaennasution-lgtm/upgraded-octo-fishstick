<?php
require_once __DIR__ . '/../db.php';
session_start();

// Hitung statistik
$count_user = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$occupied   = $pdo->query("SELECT COUNT(*) FROM rooms WHERE current_status='occupied'")->fetchColumn();
$free       = $pdo->query("SELECT COUNT(*) FROM rooms WHERE current_status='free'")->fetchColumn();

// Ambil semua user
$users = $pdo->query("SELECT * FROM users ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

// Lokasi folder upload
$uploadUrl = "../uploads/";
$uploadDir = dirname(__DIR__) . "/uploads/";
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Admin</title>

<style>
body { margin:0; font-family:Arial; background:#f5f6fa; }

/* Top Nav */
.top-nav {
    height:60px; background:#34495e; color:#fff;
    display:flex; justify-content:space-between;
    padding:15px 20px; align-items:center;
}
.top-avatar {
    width:35px; height:35px; border-radius:50%;
    object-fit:cover; margin-right:10px;
}
.logout-btn { color:#fff; margin-left:20px; text-decoration:none; }
.logout-btn:hover { text-decoration:underline; }

/* Layout */
.wrapper { display:flex; }

/* Sidebar */
.sidebar {
    width:220px; background:#2c3e50; min-height:100vh;
    padding-top:20px;
}
.sidebar a {
    display:block; padding:12px 20px;
    color:#ecf0f1; text-decoration:none;
}
.sidebar a:hover, .sidebar a.active { background:#1abc9c; }
.profile-box { text-align:center; margin-bottom:20px; }
.profile-photo {
    width:60px; height:60px; border-radius:50%;
    object-fit:cover;
}
.profile-name { font-weight:bold; margin-top:10px; color:#fff; }

/* Content */
.content { flex:1; padding:20px; }
.stats-grid {
    display:grid; grid-template-columns:repeat(3,1fr); gap:15px;
}
.stat-card {
    background:#fff; padding:20px; border-radius:8px; font-weight:bold;
}
.stat-number { font-size:28px; margin-top:10px; }
.stat-card.blue { border-left:5px solid #3498db; }
.stat-card.red { border-left:5px solid #e74c3c; }
.stat-card.green { border-left:5px solid #2ecc71; }

/* User Grid */
.user-grid {
    margin-top:25px;
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(220px,1fr));
    gap:20px;
}
.user-card {
    background:#fff; padding:15px; text-align:center;
    border-radius:8px; border:1px solid #ddd;
}
.user-img {
    width:70px; height:70px; border-radius:50%;
    object-fit:cover; border:3px solid #eee;
}
.role-badge {
    display:inline-block; padding:5px 10px;
    border-radius:6px; color:#fff; margin-top:5px; font-size:12px;
}
.role-badge.admin { background:#e67e22; }
.role-badge.user { background:#3498db; }
.role-badge.staff { background:#2ecc71; }
</style>

</head>

<body>

<!-- HEADER -->
<div class="top-nav">
    <div class="left">
        <span>Dashboard Admin</span>
    </div>

    <div class="right">
        <img src="<?= $uploadUrl ?>default.png" class="top-avatar">
        <span><?= $_SESSION['user'] ?></span>
        <a href="../logout.php" class="logout-btn">Logout</a>
    </div>
</div>

<div class="wrapper">

    <!-- SIDEBAR -->
    <div class="sidebar">
        <div class="profile-box">
            <img src="<?= $uploadUrl ?>default.png" class="profile-photo">
            <div class="profile-name"><?= $_SESSION['user'] ?></div>
        </div>

        <a href="dashboard_admin.php" class="active">📊 Dashboard</a>
        <a href="rooms.php">🏢 Ruangan</a>
        <a href="history.php">📜 History</a>
        <a href="users.php">👥 User</a>
    </div>

    <!-- CONTENT -->
    <div class="content">

        <div class="stats-grid">
            <div class="stat-card blue">
                <h3>Total User</h3>
                <div class="stat-number"><?= $count_user ?></div>
            </div>

            <div class="stat-card red">
                <h3>Ruangan Terisi</h3>
                <div class="stat-number"><?= $occupied ?></div>
            </div>

            <div class="stat-card green">
                <h3>Ruangan Kosong</h3>
                <div class="stat-number"><?= $free ?></div>
            </div>
        </div>

        <h2>Daftar User</h2>

        <div class="user-grid">

            <?php foreach ($users as $u): ?>
                <?php
                    // Nama file foto user
                    $foto = $u['photo'] ?: "default.png";

                    // Path asli file
                    $fullPath = $uploadDir . $foto;

                    // Jika foto tidak ada, pakai default
                    if (!file_exists($fullPath)) {
                        $foto = "default.png";
                    }

                    $fotoUrl = $uploadUrl . $foto;
                ?>

                <div class="user-card">
                    <img src="<?= $fotoUrl ?>" class="user-img">
                    <h3><?= htmlspecialchars($u['username']) ?></h3>
                    <p class="email"><?= htmlspecialchars($u['email']) ?></p>

                    <span class="role-badge <?= strtolower($u['role']) ?>">
                        <?= strtoupper($u['role']) ?>
                    </span>
                </div>

            <?php endforeach; ?>

        </div>

    </div>
</div>

</body>
</html>
