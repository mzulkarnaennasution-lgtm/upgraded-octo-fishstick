<?php
require_once __DIR__ . '/../db.php';
session_start();

// Hitung statistik
$count_user = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$occupied   = $pdo->query("SELECT COUNT(*) FROM rooms WHERE current_status='occupied'")->fetchColumn();
$free       = $pdo->query("SELECT COUNT(*) FROM rooms WHERE current_status='free'")->fetchColumn();

// Ambil semua user
$users = $pdo->query("SELECT * FROM users ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

// Path uploads
$uploadUrl = "../uploads/";
$uploadDir = dirname(__DIR__) . "/uploads/";
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Admin</title>

<link rel="stylesheet" href="../assets/css/admin-dashboard.css">

</head>

<body>

<!-- ================= HEADER ================= -->
<div class="top-nav">
    <div class="left">
        <span class="brand">Dashboard Admin</span>
    </div>

    <div class="right">
        <img src="../uploads/default.png" class="top-avatar">
        <span><?= $_SESSION['user'] ?></span>
        <a href="../logout.php" class="logout-btn">Logout</a>
    </div>
</div>

<!-- ================= MAIN WRAPPER ================= -->
<div class="wrapper">

    <!-- ================= SIDEBAR ================= -->
    <div class="sidebar">
        <div class="profile-box">
            <img src="../uploads/default.png" class="profile-photo">
            <div class="profile-name"><?= $_SESSION['user'] ?></div>
        </div>

        <a href="dashboard_admin.php" class="active">📊 Dashboard</a>
        <a href="rooms.php">🏢 Ruangan</a>
        <a href="history.php">📜 History</a>
        <a href="users.php">👥 User</a>
    </div>

    <!-- ================= CONTENT ================= -->
    <div class="content">

        <!-- Statistik -->
        <div class="stats-grid">

            <div class="stat-card blue">
                <h3>Total User</h3>
                <div class="stat-number"><?= $count_user ?></div>
            </div>

            <div class="stat-card red">
                <h3>Ruangan Terisi</h3>
                <div class="stat-number"><?= $occupied ?></div>
            </div>

            <div class="stat-card green">
                <h3>Ruangan Kosong</h3>
                <div class="stat-number"><?= $free ?></div>
            </div>

        </div>

        <!-- Daftar User -->
        <h2 class="section-title">Daftar User</h2>

        <div class="user-grid">

            <?php foreach ($users as $u): 
                $fotoFile = $u['photo'] ? $u['photo'] : "default.png";
                $fullPath = $uploadDir . $fotoFile;

                if (!file_exists($fullPath)) {
                    $foto = $uploadUrl . "default.png";
                } else {
                    $foto = $uploadUrl . $fotoFile;
                }
            ?>

            <div class="user-card">
                <img src="<?= $foto ?>" class="user-img">
                <h3><?= htmlspecialchars($u['username']) ?></h3>
                <p class="email"><?= htmlspecialchars($u['email']) ?></p>

                <span class="role-badge <?= strtolower($u['role']) ?>">
                    <?= strtoupper($u['role']) ?>
                </span>
            </div>

            <?php endforeach; ?>

        </div>

    </div>
</div>

</body>
</html>
