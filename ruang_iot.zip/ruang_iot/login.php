<?php
require_once __DIR__ . '/db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $username = $_POST['username'];
    $password = $_POST['password'];

    // Ambil user berdasarkan username
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username=? LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user) {

        // Cocokkan password input dengan hash database
        if (password_verify($password, $user['password'])) {

            // Simpan session
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['role']     = $user['role']; // admin / user

            // Arahkan berdasarkan role
            if ($user['role'] == 'admin') {
                header("Location: admin/dashboard_admin.php");
                exit;
            } else {
                header("Location: user/dashboard_user.php");
                exit;
            }

        } else {
            $error = "Password salah";
        }

    } else {
        $error = "Username tidak ditemukan";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login Sistem</title>
    <link rel="stylesheet" href="assets/css/login1.css">
</head>

<body>

<div class="login-container">
    <div class="login-card">

        <img src="assets/img/umri1.png" class="logo">

        <h2>Selamat Datang</h2>
        <p class="subtitle">Masuk ke sistem ruangan IoT</p>

        <?php if (!empty($error)): ?>
            <p class="error"><?= $error ?></p>
        <?php endif; ?>

        <form method="POST">

            <div class="input-group">
                <label>Username</label>
                <input type="text" name="username" required placeholder="Masukkan username">
            </div>

            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" required placeholder="Masukkan password">
            </div>

            <button type="submit" class="btn-login">Masuk</button>

        </form>

    </div>
</div>

</body>
</html>
