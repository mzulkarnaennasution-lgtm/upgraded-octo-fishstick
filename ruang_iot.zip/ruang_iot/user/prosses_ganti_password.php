<?php
session_start();
require_once __DIR__ . '/../db.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];


$stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    die("User tidak ditemukan.");
}

$password_lama        = $_POST['password_lama'];
$password_baru        = $_POST['password_baru'];
$password_konfirmasi  = $_POST['password_konfirmasi'];

if (!password_verify($password_lama, $user['password'])) {
    die("Password lama salah. <a href='ganti_password.php'>Coba lagi</a>");
}

if ($password_baru !== $password_konfirmasi) {
    die("Konfirmasi password tidak cocok. <a href='ganti_password.php'>Coba lagi</a>");
}


$newHash = password_hash($password_baru, PASSWORD_DEFAULT);

$update = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
$update->execute([$newHash, $user_id]);

echo "Password berhasil diganti! <a href='profil.php'>Kembali ke Profil</a>";
exit;
