<?php
session_start();

// Pastikan user login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Ganti Password</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #eef2f3;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .box {
            width: 380px;
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.15);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        label {
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            margin-bottom: 15px;
            border-radius: 8px;
            border: 1px solid #aaa;
            font-size: 14px;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #1976d2;
            color: white;
            border: none;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background: #125a9e;
        }

        a {
            display: block;
            margin-top: 15px;
            text-align: center;
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }

        a:hover {
            color: #1976d2;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>Ganti Password</h2>

    <form action="proses_ganti_password.php" method="POST">

        <label>Password Lama:</label>
        <input type="password" name="password_lama" required>

        <label>Password Baru:</label>
        <input type="password" name="password_baru" required>

        <label>Konfirmasi Password Baru:</label>
        <input type="password" name="password_konfirmasi" required>

        <button type="submit">Ubah Password</button>
    </form>

    <a href="profil.php">Kembali ke Profil</a>
</div>

</body>
</html>
