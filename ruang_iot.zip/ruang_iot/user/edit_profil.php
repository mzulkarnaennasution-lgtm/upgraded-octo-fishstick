<?php
session_start();

// Debug untuk cek session (hapus kalau sudah OK)
// print_r($_SESSION);

// Cegah error jika session kosong
$nama = $_SESSION['username'] ?? '';
$foto = isset($_SESSION['photo']) && $_SESSION['photo'] !== "" 
        ? $_SESSION['photo'] 
        : 'default.png';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Profil</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            padding: 30px;
            display: flex;
            justify-content: center;
        }

        .box {
            background: white;
            padding: 25px;
            width: 360px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        label {
            font-weight: bold;
            color: #444;
        }

        input[type="text"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            margin-bottom: 15px;
            border-radius: 6px;
            border: 1px solid #aaa;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #007bff;
            border: none;
            color: white;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background: #0056b3;
        }

        .back {
            display: block;
            text-align: center;
            margin-top: 15px;
            text-decoration: none;
            color: #333;
        }

        .back:hover {
            text-decoration: underline;
        }

        .foto-profil {
            display: block;
            margin: 0 auto 15px;
            border-radius: 8px;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>Edit Profil</h2>

    <form action="simpan_profil.php" method="POST" enctype="multipart/form-data">

        <label>Nama:</label>
        <input type="text" name="nama" value="<?= $nama ?>" required>

        <label>Foto Profil:</label>
        <img src="uploads/<?= $foto ?>" width="120" height="120" class="foto-profil">

        <input type="file" name="photo" accept="image/*">

        <button type="submit">Simpan Perubahan</button>
    </form>

    <a class="back" href="profil.php">Kembali ke Profil</a>
</div>

</body>
</html>
