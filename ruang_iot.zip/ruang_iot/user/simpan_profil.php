
<?php
session_start();
require_once __DIR__ . '/../db.php';

$user_id = $_SESSION['user_id'];

// Ambil nama lama
$nama = $_POST['nama'];

// --- PROSES FOTO ---
$fotoBaru = $_SESSION['photo'] ?? null;

if (!empty($_FILES['photo']['name'])) {

    $folder = "uploads/";
    if (!is_dir($folder)) mkdir($folder, 0777, true);

    $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
    $namaFile = "foto_" . time() . "." . $ext;

    move_uploaded_file($_FILES['photo']['tmp_name'], $folder . $namaFile);

    $fotoBaru = $namaFile;
}

// ---- UPDATE DATABASE ----
$update = $pdo->prepare("UPDATE users SET name=?, photo=? WHERE id=?");
$update->execute([$nama, $fotoBaru, $user_id]);

// UPDATE SESSION
$_SESSION['user'] = $nama;
$_SESSION['photo'] = $fotoBaru;

// kembali
header("Location: profil.php");
exit;
?>
