<div class="header">
    <div class="brand">User Panel</div>
    <div class="user">Hai, <?= $_SESSION['user'] ?> | <a href="logout.php" style="color:white;">Logout</a></div>
</div>
