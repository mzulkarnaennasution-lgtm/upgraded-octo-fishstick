<div class="sidebar">
    <a href="dashboard.php" class="active">Dashboard</a>
    <a href="rooms.php">Ruangan</a>
    <a href="profile.php">Profil</a>
</div>
