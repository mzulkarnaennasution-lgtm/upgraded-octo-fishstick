<?php
session_start();

$user = [
    "name"     => $_SESSION['name']     ?? "Nama User",
    "email"    => $_SESSION['email']    ?? "user@example.com",
    "username" => $_SESSION['username'] ?? "username",
    "photo"    => $_SESSION['photo']    ?? null,
];

// Cek foto — jika kosong pakai default
$photo = (!empty($user['photo']) && file_exists("uploads/" . $user['photo']))
        ? "uploads/" . $user['photo']
        : "assets/img/user.png";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Profil</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f3f4f6;
            padding: 40px;
            display: flex;
            justify-content: center;
        }

        .profile-box {
            width: 380px;
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.15);
            text-align: center;
        }

        .profile-box img {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 50%;
            border: 3px solid #4caf50;
            margin-bottom: 15px;
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
        }

        p {
            text-align: left;
            font-size: 16px;
            margin: 8px 0;
        }

        a {
            display: block;
            width: 100%;
            padding: 12px;
            margin-top: 12px;
            text-decoration: none;
            background: #4caf50;
            color: white;
            font-weight: bold;
            border-radius: 8px;
        }

        a:hover {
            background: #388e3c;
        }
    </style>
</head>
<body>

<div class="profile-box">

    <h2>Profil Saya</h2>

    <!-- FOTO PROFIL -->
    <img src="<?= $photo ?>" alt="Foto Profil">

    <p><strong>Nama:</strong> <?= htmlspecialchars($user['name']) ?></p>
    <p><strong>Username:</strong> <?= htmlspecialchars($user['username']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>

    <a href="edit_profil.php">Edit Profil</a>
    <a href="ganti_password.php">Ganti Password</a>
    <a href="dashboard_user.php" style="background:#616161;">Kembali</a>

</div>

</body>
</html>
