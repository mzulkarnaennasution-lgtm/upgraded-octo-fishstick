<?php
require_once __DIR__ . '/../db.php';
session_start();

$uploadDir = dirname(__DIR__) . "/uploads/";   
$uploadUrl = "../uploads/";                    

$fotoFile = $_SESSION['photo'] ?? "default.png";
$fotoPath = $uploadDir . $fotoFile;

if (!file_exists($fotoPath)) {
    $fotoFile = "default.png";
}

$foto = $uploadUrl . $fotoFile;
$nama = $_SESSION['username'] ?? "Profil";


$rooms = $pdo->query("SELECT * FROM rooms ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

function getStatus($val) {
    $val = strtolower(trim($val));

    if ($val === "1" || $val === "occupied" || $val === "berisi" || $val === "isi") {
        return "occupied";
    }
    return "free";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Dashboard Ruangan</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />

    <style>
        body { background:#f5f7fa; }
        .card { border-radius: 12px; }
        .status-badge {
            position:absolute; 
            top:10px; left:10px; 
            padding:6px 12px;
            border-radius:50px;
            font-size:13px;
            font-weight:bold;
            color:white;
        }
        .occupied { background:#c62828; }
        .free { background:#2e7d32; }
        .room-img {
            width:100%; 
            height:180px; 
            object-fit:cover;
            border-radius:12px 12px 0 0;
        }
    </style>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container px-4 px-lg-5">
        <a class="navbar-brand fw-bold" href="#">Dashboard Ruangan</a>

        <div class="d-flex">
            <!-- FOTO PROFIL FIX -->
            <a href="profil.php" class="d-flex align-items-center text-decoration-none">
                <img src="<?= $foto ?>"
                     width="32" height="32"
                     class="rounded-circle me-2"
                     alt="Foto Profil">

                <span class="fw-bold"><?= htmlspecialchars($nama) ?></span>
            </a>
        </div>
    </div>
</nav>

<header class="bg-dark py-5">
    <div class="container text-center text-white">
        <h1 class="fw-bolder">Informasi Ruangan</h1>
        <p class="lead text-white-50">Status ruangan terbaru</p>
    </div>
</header>

<section class="py-5">
    <div class="container px-4 px-lg-5 mt-3">
        <div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 g-4">

            <?php foreach ($rooms as $r): 
                $status = getStatus($r["current_status"]);

                $roomFile = $r["image"] ?: "free.png";
                $roomPath = "../uploads/" . $roomFile;

                if (!file_exists(dirname(__DIR__) . "/uploads/" . $roomFile)) {
                    $roomPath = "assets/img/user.png";
                }
            ?>

            <div class="col">
                <div class="card h-100 position-relative">
                    <div class="status-badge <?= $status ?>">
                        <?= $status === "occupied" ? "BERISI" : "KOSONG" ?>
                    </div>

                    <img src="<?= $roomPath ?>" class="room-img" alt="gambar">

                    <div class="card-body text-center">
                        <h5 class="fw-bold"><?= htmlspecialchars($r["name"]) ?></h5>
                        <p class="text-muted mb-1"><?= htmlspecialchars($r["location"]) ?></p>
                        <small><?= htmlspecialchars($r["description"] ?? "") ?></small>
                    </div>

                </div>
            </div>

            <?php endforeach; ?>

        </div>
    </div>
</section>

<footer class="py-4 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">© Sistem Monitoring Ruangan</p>
    </div>
</footer>

</body>
</html>
