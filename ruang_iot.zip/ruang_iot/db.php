<?php
// db.php - gunakan PDO, simpan di root project (C:\xampp\htdocs\ruang_iot\db.php)
define('DB_HOST','127.0.0.1');
define('DB_NAME','ruang_iot');
define('DB_USER','root');
define('DB_PASS','');

try {
    $pdo = new PDO(
        "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    // jangan tampilkan password di produksi
    die("DB connection failed: " . $e->getMessage());
}
